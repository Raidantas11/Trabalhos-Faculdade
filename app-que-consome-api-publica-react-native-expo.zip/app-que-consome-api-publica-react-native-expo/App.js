import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, TouchableOpacity } from 'react-native';
import axios from 'axios';

const GITHUB_API_URL = 'https://api.github.com/users/'; 

export default function App() {
  const [userData, setUserData] = useState(null); 
  const [repos, setRepos] = useState([]); 
  const [loading, setLoading] = useState(false); 
  const [error, setError] = useState(null); 

  const [username, setUsername] = useState('octocat'); 

  useEffect(() => {
    if (username) {
      setLoading(true);
      setError(null);

     
      axios
        .get(`${GITHUB_API_URL}${username}`)
        .then((response) => {
          setUserData(response.data); 
          
          axios
            .get(`${GITHUB_API_URL}${username}/repos`)
            .then((repoResponse) => {
              setRepos(repoResponse.data); 
              setLoading(false); 
            })
            .catch((repoError) => {
              console.error(repoError);
              setError('Erro ao carregar repositórios');
              setLoading(false);
            });
        })
        .catch((error) => {
          console.error(error);
          setError('Erro ao carregar dados do usuário');
          setLoading(false);
        });
    }
  }, [username]); 

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#0000ff" />
        <Text>Carregando...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.container}>
        <Text style={styles.error}>{error}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      
      {userData && (
        <View style={styles.userInfo}>
          <Text style={styles.username}>{userData.name || userData.login}</Text>
          <Text style={styles.bio}>{userData.bio || 'Sem bio'}</Text>
          <Text style={styles.followers}>Seguidores: {userData.followers}</Text>
          <Text style={styles.following}>Seguindo: {userData.following}</Text>
        </View>
      )}

      
      <TouchableOpacity style={styles.button} onPress={() => setUsername('torvalds')}>
        <Text style={styles.buttonText}>Ver repositórios de Linus Torvalds</Text>
      </TouchableOpacity>

      
      <FlatList
        data={repos}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.repoCard}>
            <Text style={styles.repoName}>{item.name}</Text>
            <Text style={styles.repoDescription}>{item.description || 'Sem descrição'}</Text>
            <Text style={styles.repoStars}>⭐ Estrelas: {item.stargazers_count}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f0f0f0',
  },
  userInfo: {
    alignItems: 'center',
    marginBottom: 20,
  },
  username: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  bio: {
    fontSize: 16,
    color: '#555',
    marginVertical: 5,
  },
  followers: {
    fontSize: 16,
    color: '#333',
  },
  following: {
    fontSize: 16,
    color: '#333',
    marginBottom: 10,
  },
  error: {
    color: 'red',
    fontSize: 18,
    textAlign: 'center',
  },
  repoCard: {
    backgroundColor: '#fff',
    padding: 15,
    marginVertical: 10,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 5,
  },
  repoName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  repoDescription: {
    fontSize: 14,
    color: '#666',
  },
  repoStars: {
    fontSize: 14,
    color: '#ffbf00',
  },
  button: {
    padding: 10,
    backgroundColor: '#007bff',
    borderRadius: 5,
    marginBottom: 20,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
});
